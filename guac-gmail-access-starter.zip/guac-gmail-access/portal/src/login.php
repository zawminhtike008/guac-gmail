<?php
require __DIR__.'/config.php';
if(!empty($_SESSION['admin_ok'])) { header('Location: index.php'); exit; }
$error='';
if($_SERVER['REQUEST_METHOD']==='POST') {
 $u=(string)($_POST['username']??''); $p=(string)($_POST['password']??'');
 if(hash_equals(getenv('ADMIN_USER')?:'',$u) && password_verify($p,getenv('ADMIN_PASSWORD_HASH')?:'')) {
  session_regenerate_id(true); $_SESSION['admin_ok']=true; $_SESSION['admin_user']=$u; header('Location: index.php'); exit;
 }
 $error='Invalid username or password';
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Guacamole Access Manager</title><style>body{font:16px system-ui;background:#f2f5f9;display:grid;place-items:center;min-height:100vh}.box{background:white;padding:28px;border-radius:14px;width:min(380px,90vw)}input,button{width:100%;box-sizing:border-box;padding:12px;margin:8px 0;border:1px solid #ccd2dc;border-radius:8px}button{background:#1d4ed8;color:white;border:0}.err{color:#b91c1c}</style></head><body><form class="box" method="post"><h2>Gmail Access Manager</h2><p>Administrator login</p><?php if($error):?><p class="err"><?=h($error)?></p><?php endif;?><label>Username<input name="username" required autocomplete="username"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><button>Sign in</button></form></body></html>
