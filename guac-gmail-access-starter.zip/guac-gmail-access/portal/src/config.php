<?php
declare(strict_types=1);
session_name('guac_access_admin');
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>true,'httponly'=>true,'samesite'=>'Strict']);
session_start();
date_default_timezone_set(getenv('APP_TIMEZONE') ?: 'UTC');
function db(): PDO {
 static $pdo=null; if ($pdo instanceof PDO) return $pdo;
 $host=getenv('DB_HOST')?:'mysql'; $port=getenv('DB_PORT')?:'3306'; $name=getenv('DB_NAME')?:'guac_access';
 $pdo=new PDO("mysql:host=$host;port=$port;dbname=$name;charset=utf8mb4",getenv('DB_USER')?:'guacaccess',getenv('DB_PASSWORD')?:'',[
  PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); return $pdo;
}
function h(string $s): string { return htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function csrf(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function need_login(): void { if(empty($_SESSION['admin_ok'])) { header('Location: login.php'); exit; } }
function check_csrf(): void { if(!hash_equals(csrf(),(string)($_POST['csrf']??''))) { http_response_code(400); exit('Invalid request token'); } }
