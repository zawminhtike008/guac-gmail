package com.triggernine.guac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.regex.Pattern;

import org.apache.guacamole.GuacamoleException;
import org.apache.guacamole.GuacamoleInvalidCredentialsException;
import org.apache.guacamole.net.auth.AbstractAuthenticationProvider;
import org.apache.guacamole.net.auth.AuthenticatedUser;
import org.apache.guacamole.net.auth.Credentials;
import org.apache.guacamole.net.auth.DelegatingUserContext;
import org.apache.guacamole.net.auth.UserContext;

/** Enforces the Gmail access table while preserving the MySQL UserContext. */
public class GmailAccessProvider extends AbstractAuthenticationProvider {
    private static final String OIDC = "openid";
    private static final String MYSQL = "mysql";
    private static final Pattern EMAIL = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    private final String jdbcUrl = required("GMAIL_ACCESS_DB_URL");
    private final String dbUser = required("GMAIL_ACCESS_DB_USER");
    private final String dbPassword = required("GMAIL_ACCESS_DB_PASSWORD");

    @Override public String getIdentifier() { return "gmail-access"; }

    // This provider supplies no connections of its own.
    @Override public UserContext getUserContext(AuthenticatedUser user) { return null; }

    @Override
    public UserContext decorate(UserContext context, AuthenticatedUser user, Credentials credentials)
            throws GuacamoleException {
        if (context == null) return null;
        if (!MYSQL.equals(context.getAuthenticationProvider().getIdentifier())) return context;
        enforce(user);
        return new DelegatingUserContext(context);
    }

    @Override
    public UserContext updateUserContext(UserContext context, AuthenticatedUser user, Credentials credentials)
            throws GuacamoleException {
        if (context == null) return null;
        if (MYSQL.equals(context.getAuthenticationProvider().getIdentifier())) enforce(user);
        return context;
    }

    @Override
    public UserContext redecorate(UserContext decorated, UserContext context,
            AuthenticatedUser user, Credentials credentials) throws GuacamoleException {
        if (context == null) return null;
        if (!MYSQL.equals(context.getAuthenticationProvider().getIdentifier())) return context;
        enforce(user);
        return new DelegatingUserContext(context);
    }

    private void enforce(AuthenticatedUser user) throws GuacamoleException {
        if (user == null || user.getAuthenticationProvider() == null
                || !OIDC.equals(user.getAuthenticationProvider().getIdentifier()))
            throw denied("Google sign-in is required.");

        String email = user.getIdentifier();
        if (email == null) throw denied("Google did not provide an email address.");
        email = email.trim().toLowerCase(Locale.ROOT);
        if (email.length() > 255 || !EMAIL.matcher(email).matches())
            throw denied("The Google email identity is invalid.");

        final String status;
        try { status = statusFor(email); }
        catch (Exception e) {
            // Fail closed. Never grant access if policy storage cannot be checked.
            throw denied("Access policy is unavailable. Contact your administrator.");
        }
        if (!"ALLOW".equals(status)) {
            if ("BLOCK".equals(status)) throw denied("This Gmail account is blocked.");
            throw denied("This Gmail account is pending approval.");
        }
    }

    private String statusFor(String email) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection c = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // Insert PENDING only if unseen. Existing ALLOW/BLOCK status is never overwritten.
            try (PreparedStatement p = c.prepareStatement(
                    "INSERT IGNORE INTO gmail_access (email,status) VALUES (?, 'PENDING')")) {
                p.setString(1, email);
                p.executeUpdate();
            }
            try (PreparedStatement p = c.prepareStatement(
                    "SELECT status FROM gmail_access WHERE email=? LIMIT 1")) {
                p.setString(1, email);
                try (ResultSet rs = p.executeQuery()) { return rs.next() ? rs.getString(1) : "PENDING"; }
            }
        }
    }

    private static GuacamoleInvalidCredentialsException denied(String message) {
        return new GuacamoleInvalidCredentialsException(message);
    }

    private static String required(String key) {
        String value = System.getenv(key);
        if (value == null || value.trim().isEmpty())
            throw new IllegalStateException("Missing environment variable: " + key);
        return value.trim();
    }
}
