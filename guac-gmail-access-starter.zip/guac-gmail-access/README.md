# Guacamole 1.6.0 Gmail access policy starter

This bundle contains a Guacamole 1.6.0 Java policy extension, a PHP administrator portal, MariaDB schema, and Compose integration snippets.

## Important behavior and limits

- Google OpenID remains the identity provider (`openid`).
- The existing MySQL extension remains the connection/permission provider (`mysql`).
- The policy extension decorates the MySQL UserContext, preserving its permissions.
- New OpenID identities are inserted as PENDING. Only ALLOW is accepted. BLOCK/PENDING and DB errors are denied.
- Non-OpenID authentication is denied when the MySQL UserContext is being decorated.
- This implementation uses the OpenID-authenticated Guacamole username/identifier as the email address. It relies on Guacamole's OpenID extension to validate the OIDC response; it does not independently validate Google's raw ID token or the `email_verified` claim. Verify that the OpenID username claim is `email` in your configuration.
- A policy change is rechecked when Guacamole updates the user context. It is not a guarantee that an already-open RDP/SSH tunnel is instantly terminated; disconnect active sessions separately for immediate revocation.
- Build and test in a maintenance window before production use.

## 1. Create the access database

Edit `sql/init.sql` and replace the placeholder password. Then run:

Open an interactive MariaDB shell:

```bash
docker exec -it mysql mariadb -u root -p
```

Then paste the contents of `sql/init.sql` into the MariaDB prompt. Before pasting, replace `REPLACE_WITH_STRONG_PASSWORD` in that file with the same long random value you will use for `GMAIL_ACCESS_DB_PASSWORD` and `DB_PASSWORD`.

This creates `guac_access.gmail_access` and a restricted `guacaccess` account. The account needs SELECT/INSERT/UPDATE only.

## 2. Build the Java extension

From this folder, with Docker available:

```bash
docker build -t guac-gmail-ext-builder ./java
mkdir -p extensions
docker run --rm -v "$PWD/extensions:/out" guac-gmail-ext-builder
```

Or use Maven in `java/`:

```bash
cd java && mvn -B clean package
mkdir -p ../extensions
cp target/guac-auth-gmail-access-1.0.0.jar ../extensions/
cd ..
```

## 3. Configure Guacamole

Merge `compose.guacamole-additions.yml` into your existing Compose file. Keep your existing `MYSQL_*`, `OPENID_*`, `ports`, and `networks` settings. The new settings are:

```yaml
environment:
  EXTENSION_PRIORITY: "openid, mysql, gmail-access"
  GMAIL_ACCESS_DB_URL: "jdbc:mysql://mysql:3306/guac_access?useSSL=false&serverTimezone=UTC"
  GMAIL_ACCESS_DB_USER: "guacaccess"
  GMAIL_ACCESS_DB_PASSWORD: "${GMAIL_ACCESS_DB_PASSWORD}"
volumes:
  - ./extensions:/etc/guacamole/extensions:ro
```

Keep the Google redirect URI matching the public URL, e.g. `https://gc.triggernine.com/guacamole/`.

## 4. Configure PHP portal

Copy `.env.example` to `.env`, then set strong unique passwords. Generate a bcrypt hash:

```bash
docker run --rm php:8.3-cli php -r 'echo password_hash("YOUR_LONG_ADMIN_PASSWORD", PASSWORD_DEFAULT), PHP_EOL;'
```

Set the result as `ADMIN_PASSWORD_HASH`. Protect `.env` with `chmod 600 .env`.

Start the portal with the provided Compose file:

```bash
docker compose -f compose.access-manager.yml up -d --build
```

It joins `opensourcepos_app_net` and does not publish a host port. In Nginx Proxy Manager create `access.triggernine.com` -> `access-manager:80`, enable HTTPS, and ideally restrict the portal by VPN or source IP.

## 5. Add a first approved user

The Gmail address must also match the username used in your existing Guacamole MySQL user records and have the correct connection permissions. Add/approve it in the portal or SQL. A Google account not already present is automatically inserted as PENDING and denied.

## 6. Test

1. Put your own Google email in `gmail_access` with status ALLOW.
2. Confirm the same email exists in Guacamole's MySQL authentication database with the intended connection permissions.
3. Sign in at `https://gc.triggernine.com/guacamole/` using Google.
4. Test a new email: it should appear as PENDING and be denied.
5. Change it to ALLOW in the portal and sign in again.
6. Change it to BLOCK and sign in again; access should be denied.
7. Try a local MySQL username/password login; the policy should reject non-OpenID identity.
8. Check logs: `docker logs guacamole --tail 150`.

## 7. NPM and network

The portal has no host port mapping. NPM must be attached to `opensourcepos_app_net` to resolve `access-manager`. Do not expose MariaDB 3306 publicly. Keep HTTPS enabled. Do not leave the portal publicly accessible without a strong password and preferably an IP/VPN restriction.

## Rollback

Remove the extension bind mount and `GMAIL_ACCESS_*` variables from Guacamole, remove the portal service, then recreate Guacamole. Keep the `guac_access` database for records until you no longer need it.
